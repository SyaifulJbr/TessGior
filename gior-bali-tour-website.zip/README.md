# GiorBaliTour - Car Rental Website

A full-stack car rental website for Bali built with Next.js 18, TypeScript, Tailwind CSS, Cloudflare D1, and Auth.js.

## Features

- 🚗 Car rental management with admin dashboard
- 🌍 Multi-language support (8 languages including RTL for Arabic)
- 🔐 Secure authentication system
- ⭐ Review system (login required)
- 📱 Fully responsive design
- 🎨 Modern UI with Tailwind CSS
- 🗄️ Database integration with Cloudflare D1
- 🔒 Admin dashboard at `/tanian` (hidden route)

## Tech Stack

- **Framework:** Next.js 18 with App Router
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **Database:** Cloudflare D1
- **ORM:** Drizzle
- **Authentication:** NextAuth.js (Auth.js)
- **Internationalization:** next-intl

## Supported Languages

- English (en)
- Indonesian (id)
- Chinese (zh)
- Korean (ko)
- Arabic (ar) - RTL support
- Turkish (tr)
- Russian (ru)
- Portuguese (pt)

## Project Structure

```
├── app/
│   ├── [locale]/              # Internationalized routes
│   │   ├── page.tsx          # Landing page
│   │   ├── cars/             # Cars listing & details
│   │   ├── about/            # About page
│   │   └── contact/          # Contact page
│   ├── (auth)/               # Auth routes
│   │   ├── login/
│   │   └── register/
│   └── (tanian)/             # Admin dashboard (hidden)
│       └── tanian/cars/      # Car management
├── components/
│   ├── admin/                # Admin components
│   ├── auth/                 # Auth forms
│   ├── cars/                 # Car components
│   ├── home/                 # Home page components
│   ├── layout/               # Header & Footer
│   └── reviews/              # Review system
├── src/
│   ├── actions/              # Server actions
│   ├── lib/
│   │   ├── auth/            # Auth configuration
│   │   └── db/              # Database schema
│   └── i18n/                # Internationalization
├── messages/                 # Translation files
├── scripts/                  # Setup scripts
│   ├── download-images.sh   # Download assets
│   └── migrations/          # Database migrations
└── public/
    └── images/              # Static assets
        ├── hero/
        ├── about/
        └── cars/

```

## Getting Started

### 1. Download Images

Run the script to download all necessary images:

```bash
chmod +x scripts/download-images.sh && ./scripts/download-images.sh
```

### 2. Environment Variables

Create a `.env.local` file:

```env
# Auth
AUTH_SECRET=your-secret-key-here

# Database (Cloudflare D1)
DATABASE_URL=your-d1-database-url

# Cloudflare
CLOUDFLARE_ACCOUNT_ID=your-account-id
CLOUDFLARE_DATABASE_ID=your-database-id
```

### 3. Database Setup

Run the migration to create tables:

```sql
# See scripts/migrations/001_initial_schema.sql
```

### 4. Install Dependencies & Run

```bash
npm install
npm run dev
```

Visit `http://localhost:3000` to see the website.

## Admin Access

The admin dashboard is located at `/tanian/cars` and is protected by server-side authentication. Only users with the "admin" role can access it.

To create an admin user, manually insert into the database with `role: 'admin'`.

## Features Breakdown

### Public Pages
- **Landing Page:** Hero carousel, features, featured cars
- **Cars Page:** Grid of all available cars
- **Car Detail:** Detailed view with specs and reviews
- **About Page:** Company information with images
- **Contact Page:** Contact form

### Authentication
- Login and registration system
- Password hashing with bcrypt
- JWT-based sessions
- Optional login (not required for browsing)

### Review System
- Star rating (1-5)
- Comment submission
- Login required to post reviews
- Display all reviews per car

### Admin Dashboard
- Protected route at `/tanian`
- Server-side role verification
- Car management (CRUD)
- Image selection from available assets
- Form validation

### Internationalization
- 8 language support
- RTL support for Arabic
- Language switcher in header
- All UI text translated

## Security Features

- Server-side authentication checks
- Password hashing with bcrypt
- Role-based access control
- Hidden admin routes
- Input validation and sanitization

## Deployment

This project is designed to work with Vercel and Cloudflare D1:

1. Connect your repository to Vercel
2. Set up Cloudflare D1 database
3. Add environment variables in Vercel
4. Deploy!

## License

MIT
