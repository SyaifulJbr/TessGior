import { LoginForm } from "@/components/auth/login-form"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Login - GiorBaliTour",
  description: "Login to your GiorBaliTour account",
}

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-muted/40 px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold">GiorBaliTour</h1>
          <p className="mt-2 text-muted-foreground">Login to your account</p>
        </div>
        <LoginForm />
      </div>
    </div>
  )
}
