import { notFound } from "next/navigation"
import { auth } from "@/lib/auth"
import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default async function TanianLayout({ children }: { children: React.ReactNode }) {
  const session = await auth()

  if (!session || (session.user as any)?.role !== "admin") {
    notFound()
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <h1 className="text-xl font-bold">Admin Dashboard</h1>
          <nav className="flex items-center gap-4">
            <Link href="/tanian/cars">
              <Button variant="ghost">Manage Cars</Button>
            </Link>
            <Link href="/">
              <Button variant="outline">View Site</Button>
            </Link>
          </nav>
        </div>
      </header>
      <main className="container mx-auto py-8 px-4">{children}</main>
    </div>
  )
}
