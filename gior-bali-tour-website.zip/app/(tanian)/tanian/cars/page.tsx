import { CarsManagement } from "@/components/admin/cars-management"

export default function AdminCarsPage() {
  return (
    <div>
      <h1 className="mb-8 text-3xl font-bold">Manage Cars</h1>
      <CarsManagement />
    </div>
  )
}
