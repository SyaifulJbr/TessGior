import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import Image from "next/image"

export default function AboutPage() {
  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-12">
        <h1 className="mb-8 text-4xl font-bold text-balance">About GiorBaliTour</h1>

        <div className="grid gap-8 md:grid-cols-2">
          <div className="space-y-4">
            <p className="text-lg leading-relaxed">
              Welcome to GiorBaliTour, your trusted partner for exploring the beautiful island of Bali. We provide
              premium car rental services with experienced drivers and all-inclusive packages.
            </p>
            <p className="leading-relaxed">
              Our 10-hour rental packages include a professional driver who knows Bali intimately, full petrol coverage,
              and comprehensive insurance. Whether you're visiting temples, beaches, or rice terraces, we ensure your
              journey is comfortable and memorable.
            </p>
            <p className="leading-relaxed">
              With a diverse fleet of well-maintained vehicles ranging from compact cars to luxury vans, we cater to
              solo travelers, couples, families, and large groups.
            </p>
          </div>

          <div className="space-y-4">
            <Image
              src="/images/about/bali-island.jpg"
              alt="Bali Island"
              width={600}
              height={400}
              className="rounded-lg object-cover"
            />
          </div>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          <div className="rounded-lg border bg-card p-6">
            <h3 className="mb-2 text-xl font-semibold">Professional Drivers</h3>
            <p className="text-muted-foreground">
              All our drivers are experienced, licensed, and knowledgeable about Bali's best destinations.
            </p>
          </div>
          <div className="rounded-lg border bg-card p-6">
            <h3 className="mb-2 text-xl font-semibold">All-Inclusive</h3>
            <p className="text-muted-foreground">
              Petrol, driver, and insurance included. No hidden fees or surprise charges.
            </p>
          </div>
          <div className="rounded-lg border bg-card p-6">
            <h3 className="mb-2 text-xl font-semibold">Flexible Itinerary</h3>
            <p className="text-muted-foreground">
              Create your own itinerary and explore Bali at your own pace during the 10-hour rental.
            </p>
          </div>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-2">
          <Image
            src="/images/about/bali-nature.jpg"
            alt="Bali Nature"
            width={600}
            height={400}
            className="rounded-lg object-cover"
          />
          <Image
            src="/images/about/bali-tari-kecak.jpg"
            alt="Bali Culture"
            width={600}
            height={400}
            className="rounded-lg object-cover"
          />
        </div>
      </main>
      <Footer />
    </>
  )
}
