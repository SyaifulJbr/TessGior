import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { CarDetail } from "@/components/cars/car-detail"

export default function CarDetailPage({ params }: { params: { id: string } }) {
  // In production, fetch car from database
  // If not found, call notFound()

  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-12">
        <CarDetail carId={params.id} />
      </main>
      <Footer />
    </>
  )
}
