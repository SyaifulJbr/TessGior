"use client"

import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { CarsList } from "@/components/cars/cars-list"
import { useTranslations } from "next-intl"

export default function CarsPage() {
  const t = useTranslations("cars")

  return (
    <>
      <Header />
      <main className="container mx-auto px-4 py-12">
        <h1 className="mb-8 text-4xl font-bold text-balance">{t("title")}</h1>
        <CarsList />
      </main>
      <Footer />
    </>
  )
}
