import { Hero } from "@/components/home/hero"
import { FeaturedCars } from "@/components/home/featured-cars"
import { Features } from "@/components/home/features"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"

export default function HomePage() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Features />
        <FeaturedCars />
      </main>
      <Footer />
    </>
  )
}
