"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { addCar, updateCar, AVAILABLE_CAR_IMAGES } from "@/actions/admin-cars"
import type { Car } from "@/lib/db/schema"

interface CarFormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  car?: Car
}

export function CarFormDialog({ open, onOpenChange, car }: CarFormDialogProps) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setLoading(true)
    setError("")

    const formData = new FormData(e.currentTarget)

    try {
      let result
      if (car) {
        result = await updateCar(car.id, formData)
      } else {
        result = await addCar(formData)
      }

      if (result.error) {
        setError(result.error)
      } else {
        onOpenChange(false)
      }
    } catch (error) {
      setError("An error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{car ? "Edit Car" : "Add New Car"}</DialogTitle>
          <DialogDescription>
            {car ? "Update the car details below" : "Fill in the details to add a new car"}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            {error && <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}

            <div className="space-y-2">
              <Label htmlFor="name">Car Name</Label>
              <Input id="name" name="name" defaultValue={car?.name} required placeholder="e.g., Toyota Avanza" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="capacity">Capacity (people)</Label>
                <Input
                  id="capacity"
                  name="capacity"
                  type="number"
                  min="1"
                  max="20"
                  defaultValue={car?.capacity}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="transmission">Transmission</Label>
                <Select name="transmission" defaultValue={car?.transmission || "automatic"}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="automatic">Automatic</SelectItem>
                    <SelectItem value="manual">Manual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="pricePerDay">Price per Day ($)</Label>
              <Input
                id="pricePerDay"
                name="pricePerDay"
                type="number"
                min="0"
                step="0.01"
                defaultValue={car?.pricePerDay}
                required
                placeholder="e.g., 50.00"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="imageFilename">Car Image</Label>
              <Select name="imageFilename" defaultValue={car?.imageFilename}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a car image" />
                </SelectTrigger>
                <SelectContent>
                  {AVAILABLE_CAR_IMAGES.map((image) => (
                    <SelectItem key={image} value={image}>
                      {image}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">Select from available car images</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                name="description"
                defaultValue={car?.description}
                required
                placeholder="Describe the car features, comfort, and suitability..."
                rows={4}
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Saving..." : car ? "Update Car" : "Add Car"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
