"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus } from "lucide-react"
import { CarFormDialog } from "./car-form-dialog"
import type { Car } from "@/lib/db/schema"

export function CarsManagement() {
  const [cars, setCars] = useState<Car[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingCar, setEditingCar] = useState<Car | null>(null)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Cars</CardTitle>
              <CardDescription>Manage your car fleet</CardDescription>
            </div>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Car
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {cars.length === 0 ? (
            <div className="flex h-40 items-center justify-center text-muted-foreground">
              No cars added yet. Click "Add Car" to get started.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Image</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Capacity</TableHead>
                  <TableHead>Transmission</TableHead>
                  <TableHead>Price/Day</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cars.map((car) => (
                  <TableRow key={car.id}>
                    <TableCell>
                      <img
                        src={`/images/cars/${car.imageFilename}`}
                        alt={car.name}
                        className="h-16 w-24 rounded object-cover"
                      />
                    </TableCell>
                    <TableCell className="font-medium">{car.name}</TableCell>
                    <TableCell>{car.capacity} people</TableCell>
                    <TableCell className="capitalize">{car.transmission}</TableCell>
                    <TableCell>${car.pricePerDay}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => setEditingCar(car)}>
                        Edit
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <CarFormDialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen} />

      {editingCar && (
        <CarFormDialog open={!!editingCar} onOpenChange={(open) => !open && setEditingCar(null)} car={editingCar} />
      )}
    </div>
  )
}
