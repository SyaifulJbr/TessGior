"use client"

import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Settings } from "lucide-react"
import Link from "next/link"
import { useTranslations } from "next-intl"
import type { Car } from "@/lib/db/schema"

interface CarCardProps {
  car: Car
}

export function CarCard({ car }: CarCardProps) {
  const t = useTranslations("cars")

  return (
    <Card className="overflow-hidden">
      <div className="aspect-video overflow-hidden">
        <img src={`/images/cars/${car.imageFilename}`} alt={car.name} className="h-full w-full object-cover" />
      </div>
      <CardHeader>
        <h3 className="text-xl font-semibold">{car.name}</h3>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Users className="h-4 w-4" />
          <span>
            {t("capacity")}: {car.capacity} people
          </span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Settings className="h-4 w-4" />
          <span className="capitalize">
            {t("transmission")}: {t(car.transmission)}
          </span>
        </div>
        <p className="text-2xl font-bold">${car.pricePerDay}</p>
        <p className="text-sm text-muted-foreground">{t("pricePerDay")}</p>
      </CardContent>
      <CardFooter>
        <Link href={`/cars/${car.id}`} className="w-full">
          <Button className="w-full">{t("viewDetails")}</Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
