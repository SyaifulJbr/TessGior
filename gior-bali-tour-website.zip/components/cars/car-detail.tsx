"use client"

import { Users, Settings, Clock, User, Fuel } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTranslations } from "next-intl"
import { ReviewsSection } from "@/components/reviews/reviews-section"

interface CarDetailProps {
  carId: string
}

export function CarDetail({ carId }: CarDetailProps) {
  const t = useTranslations("cars")

  // In production, fetch car from database using carId
  // For now, show placeholder
  const car = null

  if (!car) {
    return <div className="py-12 text-center">Car not found or loading...</div>
  }

  return (
    <>
      <div className="grid gap-8 lg:grid-cols-2">
        <div>
          <img
            src={`/images/cars/${(car as any).imageFilename}`}
            alt={(car as any).name}
            className="w-full rounded-lg object-cover"
          />
        </div>

        <div className="space-y-6">
          <div>
            <h1 className="mb-2 text-3xl font-bold">{(car as any).name}</h1>
            <p className="text-3xl font-bold text-primary">${(car as any).pricePerDay}</p>
            <p className="text-muted-foreground">{t("pricePerDay")}</p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-3 rounded-lg border p-3">
              <Users className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium">{t("capacity")}</p>
                <p className="text-sm text-muted-foreground">{(car as any).capacity} people</p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg border p-3">
              <Settings className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium">{t("transmission")}</p>
                <p className="text-sm text-muted-foreground capitalize">{t((car as any).transmission)}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg border p-3">
              <Clock className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium">Duration</p>
                <p className="text-sm text-muted-foreground">10 Hours</p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg border p-3">
              <User className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium">Driver Included</p>
                <p className="text-sm text-muted-foreground">Professional driver</p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-lg border p-3">
              <Fuel className="h-5 w-5 text-primary" />
              <div>
                <p className="font-medium">Petrol Included</p>
                <p className="text-sm text-muted-foreground">No extra fuel costs</p>
              </div>
            </div>
          </div>

          <div>
            <h2 className="mb-2 text-xl font-semibold">Description</h2>
            <p className="leading-relaxed text-muted-foreground">{(car as any).description}</p>
          </div>

          <Button size="lg" className="w-full">
            {t("bookNow")}
          </Button>
        </div>
      </div>

      <ReviewsSection carId={carId} />
    </>
  )
}
