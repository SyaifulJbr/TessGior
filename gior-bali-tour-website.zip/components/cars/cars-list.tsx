import { CarCard } from "./car-card"

export function CarsList() {
  // In production, fetch all cars from database
  const cars: any[] = []

  if (cars.length === 0) {
    return (
      <div className="py-12 text-center text-muted-foreground">
        <p>No cars available yet. Check back soon!</p>
      </div>
    )
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {cars.map((car) => (
        <CarCard key={car.id} car={car} />
      ))}
    </div>
  )
}
