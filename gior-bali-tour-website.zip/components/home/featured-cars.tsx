"use client"

import { CarCard } from "@/components/cars/car-card"
import { useTranslations } from "next-intl"

export function FeaturedCars() {
  const t = useTranslations("cars")

  // In production, fetch from database
  // For now, show placeholder
  const cars: any[] = []

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <h2 className="mb-8 text-center text-3xl font-bold">{t("title")}</h2>

        {cars.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground">
            <p>No cars available yet. Check back soon!</p>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {cars.slice(0, 3).map((car) => (
              <CarCard key={car.id} car={car} />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
