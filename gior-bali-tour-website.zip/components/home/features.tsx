"use client"

import { Clock, User, Fuel, Shield } from "lucide-react"
import { useTranslations } from "next-intl"

export function Features() {
  const t = useTranslations("features")

  const features = [
    { icon: Clock, title: t("duration"), description: "Explore Bali at your own pace" },
    { icon: User, title: t("driver"), description: "Professional and experienced" },
    { icon: Fuel, title: t("petrol"), description: "No extra fuel costs" },
    { icon: Shield, title: t("insurance"), description: "Comprehensive coverage" },
  ]

  return (
    <section className="bg-muted/50 py-16">
      <div className="container mx-auto px-4">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-center text-center">
              <div className="mb-4 rounded-full bg-primary/10 p-4">
                <feature.icon className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-semibold">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
