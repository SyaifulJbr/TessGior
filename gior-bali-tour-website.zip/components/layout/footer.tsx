import Link from "next/link"
import { Car, Mail, Phone, MapPin } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t bg-muted/50">
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-8 md:grid-cols-4">
          <div>
            <div className="mb-4 flex items-center gap-2">
              <Car className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">GiorBaliTour</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Your trusted partner for exploring Bali. Rent a car with driver and petrol for 10 hours.
            </p>
          </div>

          <div>
            <h3 className="mb-4 font-semibold">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="text-muted-foreground transition hover:text-primary">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/cars" className="text-muted-foreground transition hover:text-primary">
                  Cars
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-muted-foreground transition hover:text-primary">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground transition hover:text-primary">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 font-semibold">Services</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Car Rental with Driver</li>
              <li>10 Hours Package</li>
              <li>Full Petrol Included</li>
              <li>Comprehensive Insurance</li>
            </ul>
          </div>

          <div>
            <h3 className="mb-4 font-semibold">Contact Info</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="mt-0.5 h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Bali, Indonesia</span>
              </li>
              <li className="flex items-start gap-2">
                <Phone className="mt-0.5 h-4 w-4 text-primary" />
                <span className="text-muted-foreground">+62 123 456 789</span>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="mt-0.5 h-4 w-4 text-primary" />
                <span className="text-muted-foreground">info@giorbalitour.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} GiorBaliTour. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
