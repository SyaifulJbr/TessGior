"use client"

import type React from "react"
import { useState } from "react"
import { useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Star } from "lucide-react"
import { addReview } from "@/actions/reviews"
import Link from "next/link"
import { useTranslations } from "next-intl"

interface ReviewFormProps {
  carId: string
}

export function ReviewForm({ carId }: ReviewFormProps) {
  const { data: session } = useSession()
  const t = useTranslations("reviews")
  const [rating, setRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError("")
    setLoading(true)

    const formData = new FormData(e.currentTarget)
    formData.append("rating", rating.toString())

    try {
      const result = await addReview(carId, formData)

      if (result.error) {
        setError(result.error)
      } else {
        setSuccess(true)
        setRating(0)
        e.currentTarget.reset()

        setTimeout(() => setSuccess(false), 3000)
      }
    } catch (error) {
      setError("An error occurred")
    } finally {
      setLoading(false)
    }
  }

  if (!session) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{t("leaveReview")}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-muted-foreground">{t("loginToReview")}</p>
          <Link href="/login">
            <Button>{t("loginToReview")}</Button>
          </Link>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("leaveReview")}</CardTitle>
        <CardDescription>Share your experience with this car</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}
          {success && (
            <div className="rounded-md bg-green-50 p-3 text-sm text-green-800">Review submitted successfully!</div>
          )}

          <div className="space-y-2">
            <Label>{t("rating")}</Label>
            <div className="flex gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setRating(i + 1)}
                  onMouseEnter={() => setHoveredRating(i + 1)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`h-8 w-8 ${
                      i < (hoveredRating || rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                    }`}
                  />
                </button>
              ))}
            </div>
            {rating > 0 && <p className="text-sm text-muted-foreground">{rating} out of 5 stars</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="comment">{t("comment")}</Label>
            <Textarea
              id="comment"
              name="comment"
              required
              minLength={10}
              placeholder="Tell us about your experience..."
              rows={4}
            />
          </div>

          <Button type="submit" className="w-full" disabled={loading || rating === 0}>
            {loading ? "Submitting..." : t("submit")}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
