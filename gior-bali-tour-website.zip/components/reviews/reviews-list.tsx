import { Star } from "lucide-react"
import { getReviewsByCar } from "@/actions/reviews"

interface ReviewsListProps {
  carId: string
}

export async function ReviewsList({ carId }: ReviewsListProps) {
  const reviews = await getReviewsByCar(carId)

  if (reviews.length === 0) {
    return (
      <div>
        <h2 className="mb-4 text-2xl font-bold">Reviews</h2>
        <p className="text-muted-foreground">No reviews yet. Be the first to leave a review!</p>
      </div>
    )
  }

  return (
    <div>
      <h2 className="mb-6 text-2xl font-bold">Reviews ({reviews.length})</h2>
      <div className="space-y-4">
        {reviews.map((review) => (
          <div key={review.id} className="rounded-lg border p-4">
            <div className="mb-2 flex items-center justify-between">
              <p className="font-semibold">{review.userName}</p>
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                  />
                ))}
              </div>
            </div>
            <p className="text-muted-foreground">{review.comment}</p>
            <p className="mt-2 text-xs text-muted-foreground">{new Date(review.createdAt).toLocaleDateString()}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
