import { ReviewsList } from "./reviews-list"
import { ReviewForm } from "./review-form"

interface ReviewsSectionProps {
  carId: string
}

export async function ReviewsSection({ carId }: ReviewsSectionProps) {
  return (
    <div className="mt-12 space-y-8">
      <ReviewForm carId={carId} />
      <ReviewsList carId={carId} />
    </div>
  )
}
