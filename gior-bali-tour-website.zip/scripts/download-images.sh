#!/bin/bash

# Script to download all images for GiorBaliTour website

echo "Creating directories..."
mkdir -p public/images/hero
mkdir -p public/images/about
mkdir -p public/images/cars

echo "Downloading hero images..."
curl -o public/images/hero/barong-statue.jpg https://www.giorbalitour.com/images/hero/barong-statue.jpg
curl -o public/images/hero/kedonganan-sunset.jpg https://www.giorbalitour.com/images/hero/kedonganan-sunset.jpg
curl -o public/images/hero/nusa-penida-beach.jpg https://www.giorbalitour.com/images/hero/nusa-penida-beach.jpg

echo "Downloading about images..."
curl -o public/images/about/bali-island.jpg https://www.giorbalitour.com/images/about/bali-island.jpg
curl -o public/images/about/bali-nature.jpg https://www.giorbalitour.com/images/about/bali-nature.jpg
curl -o public/images/about/bali-tari-kecak.jpg https://www.giorbalitour.com/images/about/bali-tari-kecak.jpg

echo "Downloading car images..."
curl -o public/images/cars/all-new-avanza.png https://www.giorbalitour.com/images/cars/all-new-avanza.png
curl -o public/images/cars/avanza.png https://www.giorbalitour.com/images/cars/avanza.png
curl -o public/images/cars/hiace-commuter.png https://www.giorbalitour.com/images/cars/hiace-commuter.png
curl -o public/images/cars/hiace-premio.png https://www.giorbalitour.com/images/cars/hiace-premio.png
curl -o public/images/cars/innova-reborn.webp https://www.giorbalitour.com/images/cars/innova-reborn.webp
curl -o public/images/cars/toyota-alphard.png.webp https://www.giorbalitour.com/images/cars/toyota-alphard.png.webp
curl -o public/images/cars/toyota-vellfire.png https://www.giorbalitour.com/images/cars/toyota-vellfire.png
curl -o public/images/cars/xpander.png https://www.giorbalitour.com/images/cars/xpander.png

echo "All images downloaded successfully!"
echo "To run this script: chmod +x scripts/download-images.sh && ./scripts/download-images.sh"
