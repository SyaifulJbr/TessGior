import { drizzle } from "drizzle-orm/d1"
import * as schema from "../src/lib/db/schema"

async function seed(d1: D1Database) {
  const db = drizzle(d1, { schema })

  console.log("Starting seed...")

  // Create fake reviews
  const fakeReviews = [
    {
      userName: "John Smith",
      comment: "Amazing service! The driver was very professional and the car was in excellent condition.",
      rating: 5,
      carId: null,
      userId: null,
    },
    {
      userName: "Sarah Johnson",
      comment: "Great experience exploring Bali. Highly recommend this service for tourists!",
      rating: 5,
      carId: null,
      userId: null,
    },
    {
      userName: "Michael Chen",
      comment: "Very comfortable ride and the driver knew all the best spots in Bali.",
      rating: 4,
      carId: null,
      userId: null,
    },
    {
      userName: "Emma Williams",
      comment: "Good service overall. The car was clean and the price was reasonable.",
      rating: 4,
      carId: null,
      userId: null,
    },
    {
      userName: "David Brown",
      comment: "Perfect for our family trip. The driver was friendly and spoke good English.",
      rating: 5,
      carId: null,
      userId: null,
    },
    {
      userName: "Lisa Anderson",
      comment: "Enjoyed our day trip around Bali. Will definitely book again!",
      rating: 5,
      carId: null,
      userId: null,
    },
    {
      userName: "James Wilson",
      comment: "Reliable service with good vehicles. Made our vacation stress-free.",
      rating: 4,
      carId: null,
      userId: null,
    },
    {
      userName: "Maria Garcia",
      comment: "The driver was knowledgeable about local culture and took us to hidden gems.",
      rating: 5,
      carId: null,
      userId: null,
    },
    {
      userName: "Robert Taylor",
      comment: "Good value for money. The 10-hour rental was perfect for sightseeing.",
      rating: 4,
      carId: null,
      userId: null,
    },
    {
      userName: "Jennifer Lee",
      comment: "Professional service from start to finish. Highly recommended!",
      rating: 5,
      carId: null,
      userId: null,
    },
  ]

  for (const review of fakeReviews) {
    await db.insert(schema.reviews).values(review)
  }

  console.log("Seed completed successfully!")
}

// This script should be run with Cloudflare D1
export default seed
