"use server"

import { requireAdmin } from "@/lib/auth"
import { revalidatePath } from "next/cache"

// List of available car images
export const AVAILABLE_CAR_IMAGES = [
  "all-new-avanza.png",
  "avanza.png",
  "hiace-commuter.png",
  "hiace-premio.png",
  "innova-reborn.webp",
  "toyota-alphard.png.webp",
  "toyota-vellfire.png",
  "xpander.png",
]

export async function getCars() {
  // In production, this would query D1
  // const db = getDb(env.DB)
  // return await db.select().from(cars).orderBy(desc(cars.createdAt))

  // Mock data for now
  return []
}

export async function addCar(formData: FormData) {
  // Verify admin role
  await requireAdmin()

  const name = formData.get("name") as string
  const capacity = Number.parseInt(formData.get("capacity") as string)
  const transmission = formData.get("transmission") as "manual" | "automatic"
  const pricePerDay = Number.parseFloat(formData.get("pricePerDay") as string)
  const imageFilename = formData.get("imageFilename") as string
  const description = formData.get("description") as string

  if (!name || !capacity || !transmission || !pricePerDay || !imageFilename || !description) {
    return { error: "All fields are required" }
  }

  try {
    // In production, insert into D1
    // const db = getDb(env.DB)
    // await db.insert(cars).values({
    //   name,
    //   capacity,
    //   transmission,
    //   pricePerDay,
    //   imageFilename,
    //   description,
    // })

    revalidatePath("/tanian/cars")
    revalidatePath("/cars")
    return { success: true }
  } catch (error) {
    return { error: "Failed to add car" }
  }
}

export async function updateCar(id: string, formData: FormData) {
  // Verify admin role
  await requireAdmin()

  const name = formData.get("name") as string
  const capacity = Number.parseInt(formData.get("capacity") as string)
  const transmission = formData.get("transmission") as "manual" | "automatic"
  const pricePerDay = Number.parseFloat(formData.get("pricePerDay") as string)
  const imageFilename = formData.get("imageFilename") as string
  const description = formData.get("description") as string

  try {
    // In production, update in D1
    // const db = getDb(env.DB)
    // await db.update(cars).set({
    //   name,
    //   capacity,
    //   transmission,
    //   pricePerDay,
    //   imageFilename,
    //   description,
    // }).where(eq(cars.id, id))

    revalidatePath("/tanian/cars")
    revalidatePath("/cars")
    return { success: true }
  } catch (error) {
    return { error: "Failed to update car" }
  }
}

export async function deleteCar(id: string) {
  // Verify admin role
  await requireAdmin()

  try {
    // In production, delete from D1
    // const db = getDb(env.DB)
    // await db.delete(cars).where(eq(cars.id, id))

    revalidatePath("/tanian/cars")
    revalidatePath("/cars")
    return { success: true }
  } catch (error) {
    return { error: "Failed to delete car" }
  }
}
