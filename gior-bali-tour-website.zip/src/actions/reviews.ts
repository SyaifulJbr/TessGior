"use server"

import { auth } from "@/lib/auth"
import { revalidatePath } from "next/cache"

export async function getReviewsByCar(carId: string) {
  // In production, query D1 database
  // const db = getDb(env.DB)
  // return await db.select()
  //   .from(reviews)
  //   .where(eq(reviews.carId, carId))
  //   .orderBy(desc(reviews.createdAt))

  // Mock data for now
  return []
}

export async function addReview(carId: string, formData: FormData) {
  const session = await auth()

  if (!session) {
    return { error: "You must be logged in to leave a review" }
  }

  const rating = Number.parseInt(formData.get("rating") as string)
  const comment = formData.get("comment") as string

  if (!rating || rating < 1 || rating > 5) {
    return { error: "Please select a rating between 1 and 5" }
  }

  if (!comment || comment.trim().length < 10) {
    return { error: "Comment must be at least 10 characters long" }
  }

  try {
    const userId = (session.user as any).id
    const userName = session.user?.name || "Anonymous"

    // In production, insert into D1
    // const db = getDb(env.DB)
    // await db.insert(reviews).values({
    //   carId,
    //   userId,
    //   userName,
    //   rating,
    //   comment,
    // })

    revalidatePath(`/cars/${carId}`)
    return { success: true }
  } catch (error) {
    return { error: "Failed to submit review" }
  }
}
