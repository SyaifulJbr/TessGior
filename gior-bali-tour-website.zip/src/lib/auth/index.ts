import { getServerSession } from "next-auth"
import { authConfig } from "./config"

export async function auth() {
  return await getServerSession(authConfig)
}

export async function requireAuth() {
  const session = await auth()
  if (!session) {
    throw new Error("Unauthorized")
  }
  return session
}

export async function requireAdmin() {
  const session = await requireAuth()
  if ((session.user as any)?.role !== "admin") {
    throw new Error("Forbidden: Admin access required")
  }
  return session
}
