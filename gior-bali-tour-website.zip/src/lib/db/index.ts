import { drizzle } from "drizzle-orm/d1"
import * as schema from "./schema"
import type { D1Database } from "@cloudflare/workers-types" // Add this import to declare D1Database

// This will be used with Cloudflare D1
export function getDb(d1: D1Database) {
  return drizzle(d1, { schema })
}

export { schema }
