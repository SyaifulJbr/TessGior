import type { NextRequest } from "next/server"
import createMiddleware from "next-intl/middleware"

// Internationalization middleware
const intlMiddleware = createMiddleware({
  locales: ["en", "id", "zh", "ko", "ar", "tr", "ru", "pt"],
  defaultLocale: "en",
})

export default function middleware(request: NextRequest) {
  // Apply internationalization middleware
  return intlMiddleware(request)
}

export const config = {
  matcher: ["/((?!api|_next|_vercel|.*\\..*).*)"],
}
